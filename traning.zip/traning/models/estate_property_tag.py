# -*- coding: utf-8 -*-

from odoo import fields, models, api, _

class PropertyTag(models.Model):
    _name = 'property.tag'

    name = fields.Char()

