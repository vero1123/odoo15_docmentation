# -*- coding: utf-8 -*-

from odoo import fields, models, api, _

class PropertyType(models.Model):
    _name = 'property.type'


    name = fields.Char()
    buyer = fields.Char()
    seller = fields.Many2one('res.partner')
