# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Traning',
    'version' : '15',
    'summary': 'Traning Course',
    'sequence': 10,
    'description': """
                Traning Course
    """,
    'author': "Veronica Safwat",
    'category': 'Category',
    'depends' : ['base'],
    'data': [
       'security/ir.model.access.csv',
       'views/realestate.xml',
       'views/estate_property_type.xml',
       'views/estate_property_tag.xml',
       'views/estate_property_offer.xml',

    ],

    'installable': True,
    'application': True,
    'auto_install': False,

    'license': 'LGPL-3',
}
