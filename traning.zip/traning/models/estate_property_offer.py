# -*- coding: utf-8 -*-

from odoo import fields, models, api, _

class PropertyOffer(models.Model):
    _name = 'property.offer'

    price = fields.Float()
    partner_id = fields.Many2one('res.partner',required=True)
    property_id = fields.Many2one('real.estate',required=True)
    state = fields.Selection(
        [('accepted', 'Accepted'), ('refused', 'Refused')],
        default='new',copy=False
    )

