# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from datetime import datetime

class RealEstate(models.Model):
    _name = 'real.estate'

    name = fields.Many2one('property.type',required=True,string="Title")
    buyer = fields.Many2one('res.partner')
    seller = fields.Many2one('res.partner')
    description = fields.Text()
    postcode = fields.Char()
    date_availability = fields.Date(default=datetime.today(),copy=False)
    expected_price = fields.Float(required=True)
    selling_price = fields.Float(readonly=True,copy=False)
    bedrooms = fields.Integer(default="2")
    living_area = fields.Integer()
    facades = fields.Integer()
    garage = fields.Boolean()
    garden = fields.Boolean()
    garden_area = fields.Integer()
    garden_orientation = fields.Selection(
        [('north', 'North'), ('west', 'West'),('east','East'),('south','south')],
    )
    active = fields.Boolean()
    state = fields.Selection(
        [('new', 'New'), ('offer received', 'Offer Received'),('offer received', 'Offer Received'),('offer accepted', 'Offer Accepted'),('sold', 'Sold'),
         ('canceled,', 'Canceled,') ],
        default='new'
    )
    tags = fields.Many2many('property.tag')
    offer_ids = fields.One2many('property.offer','property_id')


